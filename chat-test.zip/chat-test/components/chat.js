import React from 'react';
import * as FlexWebChat from "@twilio/flex-webchat-ui";

//import {appConfig} from '/assets/webchat-appConfig.js';

/** 
import dynamic from 'next/dynamic'

const FlexWebChat = dynamic(() => import('@twilio/flex-webchat-ui'), {
  ssr: false,
})
*/

class Chat extends React.Component {



  state = {};

  constructor(props) {
    super(props);

    const { configuration } = props;
    FlexWebChat.Manager.create(configuration)
      .then(manager => this.setState({ manager }))
      .catch(error => this.setState({ error })); 
    }

  render() {
    const { manager, error } = this.state;
    
    //console.log(appConfig);
      

    if (manager) {
      manager.strings.PredefinedChatMessageBody = "I am a new Welcome Message";
      FlexWebChat.MainHeader.defaultProps.titleText = 'Chat with us now by default!';
      FlexWebChat.PreEngagementCanvas.Content.preEngagementConfig  = 'sdf';
      
      return (
        <FlexWebChat.ContextProvider manager={manager}>
          <FlexWebChat.RootContainer/>
        </FlexWebChat.ContextProvider>
      );
    }

    if (error) {
      console.error("Failed to initialize Flex Web Chat", error);
    }

    return null;
  }
}

export default Chat;
