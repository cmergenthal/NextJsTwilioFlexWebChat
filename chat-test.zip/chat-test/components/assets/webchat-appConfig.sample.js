var appConfig = {
    //  change the your AccountSid
    accountSid: "AC...",
    // change to your Flex Flow SID
    flexFlowSid: "FO...",
    colorTheme: {
        overrides: brandedColors
    }
}