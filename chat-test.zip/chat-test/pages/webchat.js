import dynamic from 'next/dynamic'
import {appConfig} from '../components/assets/webchat-appConfig.js';


const Chat = dynamic(() => import('../components/chat'), {
  ssr: false
})

export default function Jello(){
 

    return (

        <>
      <Chat configuration={appConfig}></Chat>
        </>
        )

}
