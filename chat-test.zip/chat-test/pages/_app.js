import '../styles/globals.css'

function MyApp({ Component, pageProps }) {


  return (
  <>
        <script id="my-script" src="https://assets.flex.twilio.com/releases/flex-webchat-ui/2.9.1/twilio-flex-webchat.min.js" integrity="sha512-yBmOHVWuWT6HOjfgPYkFe70bboby/BTj9TGHXTlEatWnYkW5fFezXqW9ZgNtuRUqHWrzNXVsqu6cKm3Y04kHMA==" crossOrigin="anonymous" >
        </script>
 
  <Component {...pageProps} />


  </>
  )
}

export default MyApp
